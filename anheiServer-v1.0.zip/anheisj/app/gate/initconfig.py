#coding:utf8
'''
Created on 2013-8-14

@author: lan
'''

def loadModule():
    import gateservice
    from gaterootapp import *
    from localservice import *