#coding:utf8
'''
Created on 2013-8-13

@author: lan
'''
from gate import initconfig

initconfig.loadModule()