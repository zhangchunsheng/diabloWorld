#coding:utf8
'''
Created on 2013-8-13

@author: lan
'''
from net import initconfig

initconfig.loadModule()