#coding:utf8
'''
Created on 2013-8-13

@author: lan
'''
from game import initconfig

initconfig.loadModule()