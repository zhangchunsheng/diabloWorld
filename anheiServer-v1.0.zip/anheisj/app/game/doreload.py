#coding:utf8
'''
Created on 2013-8-15

@author: lan
'''
from dataloader import load_config_data


load_config_data()